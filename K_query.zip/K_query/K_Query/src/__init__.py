"""
K-Query - Self-Hosted LLM DevOps Assistant

A Slack bot that answers DevOps questions using a local Llama model 
with kubectl and Prometheus integration.
"""

__version__ = "1.0.0"
__author__ = "K-Query Team"
__email__ = "team@k-query.dev"